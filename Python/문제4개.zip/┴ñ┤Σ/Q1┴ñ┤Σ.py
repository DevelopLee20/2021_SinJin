# int(): 괄호안의 내용을 정수로 만들어줌
# input(): 사용자에게 입력 받을 수 있음
a = int(input())
b = int(input())

# if, elif, else: 조건문
# print(): 괄호 내용을 출력함
if a > b:
    print('>')
elif a < b:
    print('<')
else:
    print('==')